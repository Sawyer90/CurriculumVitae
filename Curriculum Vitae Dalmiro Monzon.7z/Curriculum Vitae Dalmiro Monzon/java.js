document.getElementById("boton").onclick = function () {
    
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
}

document.getElementById("menu1").onclick = function () {

  window.scrollTo(0,position(document.getElementById("jtts1")))
   
  
}
